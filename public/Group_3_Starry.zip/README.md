
# for the Tarot gpt feature, there is a limit on the token number being ask, 
# so for example, if you choose Celtic Cross(Ten cards) to play, the fortune
# teller may not give you back the information on the 7th-10th card as it exceed the 
# token limit.